import { Building2, Users, DoorOpen, AlertTriangle } from "lucide-react";
import { StatCard } from "@/components/stat-card";
import { Button } from "@/components/ui/button";
import { Link } from "wouter";

export default function Dashboard() {
  return (
    <div className="space-y-8">
      <div>
        <h1 className="text-3xl font-semibold">Dashboard</h1>
        <p className="text-muted-foreground mt-2">
          Overview of academic data and statistics
        </p>
      </div>

      <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-4">
        <Link href="/colleges">
          <StatCard
            title="Total Colleges"
            value="4"
            icon={Building2}
            onClick={() => {}}
          />
        </Link>
        <Link href="/students">
          <StatCard
            title="Total Students"
            value="1,234"
            subtitle="678 Male, 556 Female"
            icon={Users}
            onClick={() => {}}
          />
        </Link>
        <Link href="/rooms">
          <StatCard
            title="Total Rooms"
            value="86"
            subtitle="72 Assigned, 14 Available"
            icon={DoorOpen}
            onClick={() => {}}
          />
        </Link>
        <Link href="/incidents">
          <StatCard
            title="Total Incidents"
            value="47"
            subtitle="23 Repeated, 15 Medical, 9 Dismissed"
            icon={AlertTriangle}
            onClick={() => {}}
          />
        </Link>
      </div>

      <div className="grid gap-6 md:grid-cols-2">
        <div className="space-y-4">
          <h2 className="text-xl font-semibold">Quick Actions</h2>
          <div className="grid gap-3">
            <Link href="/students">
              <Button
                variant="outline"
                className="w-full justify-start gap-2"
                data-testid="button-manage-students"
              >
                <Users className="h-4 w-4" />
                Manage Students
              </Button>
            </Link>
            <Link href="/colleges">
              <Button
                variant="outline"
                className="w-full justify-start gap-2"
                data-testid="button-view-structure"
              >
                <Building2 className="h-4 w-4" />
                View College Structure
              </Button>
            </Link>
            <Link href="/incidents">
              <Button
                variant="outline"
                className="w-full justify-start gap-2"
                data-testid="button-view-incidents"
              >
                <AlertTriangle className="h-4 w-4" />
                View Incidents
              </Button>
            </Link>
          </div>
        </div>

        <div className="space-y-4">
          <h2 className="text-xl font-semibold">Recent Activity</h2>
          <div className="space-y-3">
            <div className="rounded-lg border p-4">
              <p className="text-sm font-medium">New student registered</p>
              <p className="text-xs text-muted-foreground mt-1">
                John Doe added to Mathematics Year 1
              </p>
            </div>
            <div className="rounded-lg border p-4">
              <p className="text-sm font-medium">Incident reported</p>
              <p className="text-xs text-muted-foreground mt-1">
                Medical discharge for Sarah Johnson
              </p>
            </div>
            <div className="rounded-lg border p-4">
              <p className="text-sm font-medium">Room assigned</p>
              <p className="text-xs text-muted-foreground mt-1">
                Room 305 assigned to Physics Year 2
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
