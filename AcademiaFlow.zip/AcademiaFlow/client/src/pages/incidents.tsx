import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { queryClient, apiRequest } from "@/lib/queryClient";
import type { Incident, InsertIncident, Student, Faculty, Year } from "@shared/schema";
import { IncidentList } from "@/components/incident-list";
import { SearchFilter } from "@/components/search-filter";
import { IncidentDialog } from "@/components/incident-dialog";
import { DeleteAlertDialog } from "@/components/delete-alert-dialog";
import { Button } from "@/components/ui/button";
import { Plus } from "lucide-react";
import { useToast } from "@/hooks/use-toast";

export default function Incidents() {
  const [search, setSearch] = useState("");
  const [type, setType] = useState("all");
  const [faculty, setFaculty] = useState("all");
  const [dialogOpen, setDialogOpen] = useState(false);
  const [deleteDialogOpen, setDeleteDialogOpen] = useState(false);
  const [selectedIncident, setSelectedIncident] = useState<Incident | undefined>();
  const [incidentToDelete, setIncidentToDelete] = useState<string | undefined>();
  const { toast } = useToast();

  const { data: incidents = [], isLoading } = useQuery<Incident[]>({
    queryKey: ["/api/incidents"],
  });

  const { data: students = [] } = useQuery<Student[]>({
    queryKey: ["/api/students"],
  });

  const { data: faculties = [] } = useQuery<Faculty[]>({
    queryKey: ["/api/faculties"],
  });

  const { data: years = [] } = useQuery<Year[]>({
    queryKey: ["/api/years"],
  });

  const createMutation = useMutation({
    mutationFn: (data: InsertIncident) => apiRequest("/api/incidents", "POST", data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/incidents"] });
      toast({ title: "Success", description: "Incident created successfully" });
    },
    onError: () => {
      toast({ title: "Error", description: "Failed to create incident", variant: "destructive" });
    },
  });

  const updateMutation = useMutation({
    mutationFn: ({ id, data }: { id: string; data: InsertIncident }) =>
      apiRequest(`/api/incidents/${id}`, "PATCH", data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/incidents"] });
      toast({ title: "Success", description: "Incident updated successfully" });
    },
    onError: () => {
      toast({ title: "Error", description: "Failed to update incident", variant: "destructive" });
    },
  });

  const deleteMutation = useMutation({
    mutationFn: (id: string) => apiRequest(`/api/incidents/${id}`, "DELETE"),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/incidents"] });
      toast({ title: "Success", description: "Incident deleted successfully" });
    },
    onError: () => {
      toast({ title: "Error", description: "Failed to delete incident", variant: "destructive" });
    },
  });

  const handleSubmit = (data: InsertIncident) => {
    if (selectedIncident) {
      updateMutation.mutate({ id: selectedIncident.id, data });
    } else {
      createMutation.mutate(data);
    }
  };

  const confirmDelete = () => {
    if (incidentToDelete) {
      deleteMutation.mutate(incidentToDelete);
      setIncidentToDelete(undefined);
    }
  };

  const enrichedIncidents = incidents.map((incident) => {
    const student = students.find((s) => s.id === incident.studentId);
    const studentFaculty = student ? faculties.find((f) => f.id === student.facultyId) : null;
    const studentYear = student ? years.find((y) => y.id === student.yearId) : null;

    return {
      id: incident.id,
      studentName: student?.name || "Unknown Student",
      type: incident.type,
      description: incident.description || undefined,
      date: incident.date,
      faculty: studentFaculty?.name || "Unknown",
      year: studentYear?.name || "Unknown",
    };
  });

  const filteredIncidents = enrichedIncidents.filter((incident) => {
    const matchesSearch =
      incident.studentName.toLowerCase().includes(search.toLowerCase()) ||
      incident.description?.toLowerCase().includes(search.toLowerCase());
    const matchesType = type === "all" || incident.type === type;
    const matchesFaculty = faculty === "all" || incident.faculty === faculty;
    return matchesSearch && matchesType && matchesFaculty;
  });

  const uniqueFaculties = Array.from(new Set(enrichedIncidents.map((i) => i.faculty)));

  return (
    <div className="space-y-8">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-semibold">Incidents</h1>
          <p className="text-muted-foreground mt-2">
            Track and manage academic incidents
          </p>
        </div>
        <Button
          onClick={() => {
            setSelectedIncident(undefined);
            setDialogOpen(true);
          }}
          data-testid="button-add-incident"
        >
          <Plus className="h-4 w-4 mr-2" />
          Add Incident
        </Button>
      </div>

      <SearchFilter
        searchValue={search}
        onSearchChange={setSearch}
        filters={[
          {
            label: "Type",
            value: type,
            options: [
              { value: "all", label: "All Types" },
              { value: "Repeated", label: "Repeated" },
              { value: "Dismissed", label: "Dismissed" },
              { value: "Medical Discharge", label: "Medical Discharge" },
            ],
            onChange: setType,
          },
          {
            label: "Faculty",
            value: faculty,
            options: [
              { value: "all", label: "All Faculties" },
              ...uniqueFaculties.map((f) => ({ value: f, label: f })),
            ],
            onChange: setFaculty,
          },
        ]}
        onClearFilters={() => {
          setSearch("");
          setType("all");
          setFaculty("all");
        }}
      />

      {isLoading ? (
        <div className="text-center py-8">Loading incidents...</div>
      ) : (
        <IncidentList incidents={filteredIncidents} />
      )}

      <IncidentDialog
        open={dialogOpen}
        onOpenChange={(open) => {
          setDialogOpen(open);
          if (!open) setSelectedIncident(undefined);
        }}
        onSubmit={handleSubmit}
        incident={selectedIncident}
        students={students}
      />

      <DeleteAlertDialog
        open={deleteDialogOpen}
        onOpenChange={setDeleteDialogOpen}
        onConfirm={confirmDelete}
        title="Delete Incident"
        description="Are you sure you want to delete this incident? This action cannot be undone."
      />
    </div>
  );
}
