import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { queryClient, apiRequest } from "@/lib/queryClient";
import type { Student, InsertStudent, Faculty, Year } from "@shared/schema";
import { StudentTable } from "@/components/student-table";
import { SearchFilter } from "@/components/search-filter";
import { StudentDialog } from "@/components/student-dialog";
import { DeleteAlertDialog } from "@/components/delete-alert-dialog";
import { Button } from "@/components/ui/button";
import { Plus } from "lucide-react";
import { useToast } from "@/hooks/use-toast";

export default function Students() {
  const [search, setSearch] = useState("");
  const [faculty, setFaculty] = useState("all");
  const [year, setYear] = useState("all");
  const [dialogOpen, setDialogOpen] = useState(false);
  const [deleteDialogOpen, setDeleteDialogOpen] = useState(false);
  const [selectedStudent, setSelectedStudent] = useState<Student | undefined>();
  const [studentToDelete, setStudentToDelete] = useState<string | undefined>();
  const { toast } = useToast();

  const { data: students = [], isLoading: studentsLoading } = useQuery<Student[]>({
    queryKey: ["/api/students"],
  });

  const { data: faculties = [] } = useQuery<Faculty[]>({
    queryKey: ["/api/faculties"],
  });

  const { data: years = [] } = useQuery<Year[]>({
    queryKey: ["/api/years"],
  });

  const createMutation = useMutation({
    mutationFn: (data: InsertStudent) => apiRequest("/api/students", "POST", data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/students"] });
      toast({ title: "Success", description: "Student created successfully" });
    },
    onError: () => {
      toast({ title: "Error", description: "Failed to create student", variant: "destructive" });
    },
  });

  const updateMutation = useMutation({
    mutationFn: ({ id, data }: { id: string; data: InsertStudent }) =>
      apiRequest(`/api/students/${id}`, "PATCH", data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/students"] });
      toast({ title: "Success", description: "Student updated successfully" });
    },
    onError: () => {
      toast({ title: "Error", description: "Failed to update student", variant: "destructive" });
    },
  });

  const deleteMutation = useMutation({
    mutationFn: (id: string) => apiRequest(`/api/students/${id}`, "DELETE"),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/students"] });
      toast({ title: "Success", description: "Student deleted successfully" });
    },
    onError: () => {
      toast({ title: "Error", description: "Failed to delete student", variant: "destructive" });
    },
  });

  const handleSubmit = (data: InsertStudent) => {
    if (selectedStudent) {
      updateMutation.mutate({ id: selectedStudent.id, data });
    } else {
      createMutation.mutate(data);
    }
  };

  const handleEdit = (student: Student) => {
    setSelectedStudent(student);
    setDialogOpen(true);
  };

  const handleDelete = (studentId: string) => {
    setStudentToDelete(studentId);
    setDeleteDialogOpen(true);
  };

  const confirmDelete = () => {
    if (studentToDelete) {
      deleteMutation.mutate(studentToDelete);
      setStudentToDelete(undefined);
    }
  };

  const enrichedStudents = students.map((student) => {
    const studentFaculty = faculties.find((f) => f.id === student.facultyId);
    const studentYear = years.find((y) => y.id === student.yearId);
    return {
      id: student.id,
      name: student.name,
      gender: student.gender,
      faculty: studentFaculty?.name || "Unknown",
      year: studentYear?.name || "Unknown",
      incidentType: student.incidentType || undefined,
    };
  });

  const filteredStudents = enrichedStudents.filter((student) => {
    const matchesSearch = student.name.toLowerCase().includes(search.toLowerCase());
    const matchesFaculty = faculty === "all" || student.faculty === faculty;
    const matchesYear = year === "all" || student.year === year;
    return matchesSearch && matchesFaculty && matchesYear;
  });

  const uniqueFaculties = Array.from(new Set(enrichedStudents.map((s) => s.faculty)));
  const uniqueYears = Array.from(new Set(enrichedStudents.map((s) => s.year)));

  return (
    <div className="space-y-8">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-semibold">Students</h1>
          <p className="text-muted-foreground mt-2">
            Manage student records and information
          </p>
        </div>
        <Button
          onClick={() => {
            setSelectedStudent(undefined);
            setDialogOpen(true);
          }}
          data-testid="button-add-student"
        >
          <Plus className="h-4 w-4 mr-2" />
          Add Student
        </Button>
      </div>

      <SearchFilter
        searchValue={search}
        onSearchChange={setSearch}
        filters={[
          {
            label: "Faculty",
            value: faculty,
            options: [
              { value: "all", label: "All Faculties" },
              ...uniqueFaculties.map((f) => ({ value: f, label: f })),
            ],
            onChange: setFaculty,
          },
          {
            label: "Year",
            value: year,
            options: [
              { value: "all", label: "All Years" },
              ...uniqueYears.map((y) => ({ value: y, label: y })),
            ],
            onChange: setYear,
          },
        ]}
        onClearFilters={() => {
          setSearch("");
          setFaculty("all");
          setYear("all");
        }}
      />

      {studentsLoading ? (
        <div className="text-center py-8">Loading students...</div>
      ) : (
        <StudentTable
          students={filteredStudents}
          onEdit={(student) => {
            const original = students.find((s) => s.id === student.id);
            if (original) handleEdit(original);
          }}
          onDelete={(id) => handleDelete(id)}
        />
      )}

      <StudentDialog
        open={dialogOpen}
        onOpenChange={(open) => {
          setDialogOpen(open);
          if (!open) setSelectedStudent(undefined);
        }}
        onSubmit={handleSubmit}
        student={selectedStudent}
        faculties={faculties}
        years={years}
      />

      <DeleteAlertDialog
        open={deleteDialogOpen}
        onOpenChange={setDeleteDialogOpen}
        onConfirm={confirmDelete}
        title="Delete Student"
        description="Are you sure you want to delete this student? This action cannot be undone."
      />
    </div>
  );
}
