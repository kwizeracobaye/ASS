import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { queryClient, apiRequest } from "@/lib/queryClient";
import type { Room, InsertRoom, Block, Faculty, Year } from "@shared/schema";
import { RoomCard } from "@/components/room-card";
import { RoomDialog } from "@/components/room-dialog";
import { DeleteAlertDialog } from "@/components/delete-alert-dialog";
import { Button } from "@/components/ui/button";
import { Plus, Pencil, Trash2 } from "lucide-react";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { useToast } from "@/hooks/use-toast";

export default function Rooms() {
  const [selectedBlock, setSelectedBlock] = useState("all");
  const [dialogOpen, setDialogOpen] = useState(false);
  const [deleteDialogOpen, setDeleteDialogOpen] = useState(false);
  const [selectedRoom, setSelectedRoom] = useState<Room | undefined>();
  const [roomToDelete, setRoomToDelete] = useState<string | undefined>();
  const { toast } = useToast();

  const { data: rooms = [], isLoading } = useQuery<Room[]>({
    queryKey: ["/api/rooms"],
  });

  const { data: blocks = [] } = useQuery<Block[]>({
    queryKey: ["/api/blocks"],
  });

  const { data: faculties = [] } = useQuery<Faculty[]>({
    queryKey: ["/api/faculties"],
  });

  const { data: years = [] } = useQuery<Year[]>({
    queryKey: ["/api/years"],
  });

  const createMutation = useMutation({
    mutationFn: (data: InsertRoom) => apiRequest("/api/rooms", "POST", data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/rooms"] });
      toast({ title: "Success", description: "Room created successfully" });
    },
    onError: () => {
      toast({ title: "Error", description: "Failed to create room", variant: "destructive" });
    },
  });

  const updateMutation = useMutation({
    mutationFn: ({ id, data }: { id: string; data: InsertRoom }) =>
      apiRequest(`/api/rooms/${id}`, "PATCH", data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/rooms"] });
      toast({ title: "Success", description: "Room updated successfully" });
    },
    onError: () => {
      toast({ title: "Error", description: "Failed to update room", variant: "destructive" });
    },
  });

  const deleteMutation = useMutation({
    mutationFn: (id: string) => apiRequest(`/api/rooms/${id}`, "DELETE"),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/rooms"] });
      toast({ title: "Success", description: "Room deleted successfully" });
    },
    onError: () => {
      toast({ title: "Error", description: "Failed to delete room", variant: "destructive" });
    },
  });

  const handleSubmit = (data: InsertRoom) => {
    if (selectedRoom) {
      updateMutation.mutate({ id: selectedRoom.id, data });
    } else {
      createMutation.mutate(data);
    }
  };

  const confirmDelete = () => {
    if (roomToDelete) {
      deleteMutation.mutate(roomToDelete);
      setRoomToDelete(undefined);
    }
  };

  const enrichedRooms = rooms.map((room) => {
    const block = blocks.find((b) => b.id === room.blockId);
    const roomFaculty = room.facultyId ? faculties.find((f) => f.id === room.facultyId) : null;
    const roomYear = room.yearId ? years.find((y) => y.id === room.yearId) : null;

    return {
      id: room.id,
      roomName: room.name,
      blockName: block?.name || "Unknown Block",
      assignedTo: roomFaculty && roomYear
        ? { faculty: roomFaculty.name, year: roomYear.name }
        : undefined,
    };
  });

  const filteredRooms = enrichedRooms.filter(
    (room) => selectedBlock === "all" || room.blockName === selectedBlock
  );

  const uniqueBlocks = Array.from(new Set(enrichedRooms.map((r) => r.blockName)));

  return (
    <div className="space-y-8">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-semibold">Rooms & Blocks</h1>
          <p className="text-muted-foreground mt-2">
            Manage classroom allocations and assignments
          </p>
        </div>
        <Button
          onClick={() => {
            setSelectedRoom(undefined);
            setDialogOpen(true);
          }}
          data-testid="button-add-room"
        >
          <Plus className="h-4 w-4 mr-2" />
          Add Room
        </Button>
      </div>

      <div className="flex items-center gap-4">
        <Select value={selectedBlock} onValueChange={setSelectedBlock}>
          <SelectTrigger className="w-[250px]" data-testid="select-block">
            <SelectValue placeholder="Filter by block" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">All Blocks</SelectItem>
            {uniqueBlocks.map((block) => (
              <SelectItem key={block} value={block}>
                {block}
              </SelectItem>
            ))}
          </SelectContent>
        </Select>
        {selectedBlock !== "all" && (
          <Button
            variant="outline"
            onClick={() => setSelectedBlock("all")}
            data-testid="button-clear-block-filter"
          >
            Clear Filter
          </Button>
        )}
      </div>

      {isLoading ? (
        <div className="text-center py-8">Loading rooms...</div>
      ) : (
        <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
          {filteredRooms.map((room) => (
            <div key={room.id} className="relative group">
              <RoomCard {...room} />
              <div className="absolute top-2 right-2 flex gap-2 opacity-0 group-hover:opacity-100 transition-opacity">
                <Button
                  variant="secondary"
                  size="icon"
                  onClick={() => {
                    const original = rooms.find((r) => r.id === room.id);
                    if (original) {
                      setSelectedRoom(original);
                      setDialogOpen(true);
                    }
                  }}
                  data-testid={`button-edit-${room.id}`}
                >
                  <Pencil className="h-4 w-4" />
                </Button>
                <Button
                  variant="secondary"
                  size="icon"
                  onClick={() => {
                    setRoomToDelete(room.id);
                    setDeleteDialogOpen(true);
                  }}
                  data-testid={`button-delete-${room.id}`}
                >
                  <Trash2 className="h-4 w-4" />
                </Button>
              </div>
            </div>
          ))}
        </div>
      )}

      <RoomDialog
        open={dialogOpen}
        onOpenChange={(open) => {
          setDialogOpen(open);
          if (!open) setSelectedRoom(undefined);
        }}
        onSubmit={handleSubmit}
        room={selectedRoom}
        blocks={blocks}
        faculties={faculties}
        years={years}
      />

      <DeleteAlertDialog
        open={deleteDialogOpen}
        onOpenChange={setDeleteDialogOpen}
        onConfirm={confirmDelete}
        title="Delete Room"
        description="Are you sure you want to delete this room? This action cannot be undone."
      />
    </div>
  );
}
