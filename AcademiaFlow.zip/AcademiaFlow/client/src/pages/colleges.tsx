import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { queryClient, apiRequest } from "@/lib/queryClient";
import type { College, InsertCollege, Faculty, InsertFaculty, Year, Student } from "@shared/schema";
import { CollegeTree } from "@/components/college-tree";
import { StatisticsPanel } from "@/components/statistics-panel";
import { CollegeDialog } from "@/components/college-dialog";
import { FacultyDialog } from "@/components/faculty-dialog";
import { DeleteAlertDialog } from "@/components/delete-alert-dialog";
import { Button } from "@/components/ui/button";
import { Plus } from "lucide-react";
import { useToast } from "@/hooks/use-toast";

export default function Colleges() {
  const [collegeDialogOpen, setCollegeDialogOpen] = useState(false);
  const [facultyDialogOpen, setFacultyDialogOpen] = useState(false);
  const [deleteDialogOpen, setDeleteDialogOpen] = useState(false);
  const [selectedCollege, setSelectedCollege] = useState<College | undefined>();
  const [selectedFaculty, setSelectedFaculty] = useState<Faculty | undefined>();
  const [deleteTarget, setDeleteTarget] = useState<{ type: "college" | "faculty"; id: string } | undefined>();
  const { toast } = useToast();

  const { data: colleges = [], isLoading: collegesLoading } = useQuery<College[]>({
    queryKey: ["/api/colleges"],
  });

  const { data: faculties = [] } = useQuery<Faculty[]>({
    queryKey: ["/api/faculties"],
  });

  const { data: years = [] } = useQuery<Year[]>({
    queryKey: ["/api/years"],
  });

  const { data: students = [] } = useQuery<Student[]>({
    queryKey: ["/api/students"],
  });

  const createCollegeMutation = useMutation({
    mutationFn: (data: InsertCollege) => apiRequest("/api/colleges", "POST", data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/colleges"] });
      toast({ title: "Success", description: "College created successfully" });
    },
    onError: () => {
      toast({ title: "Error", description: "Failed to create college", variant: "destructive" });
    },
  });

  const updateCollegeMutation = useMutation({
    mutationFn: ({ id, data }: { id: string; data: InsertCollege }) =>
      apiRequest(`/api/colleges/${id}`, "PATCH", data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/colleges"] });
      toast({ title: "Success", description: "College updated successfully" });
    },
    onError: () => {
      toast({ title: "Error", description: "Failed to update college", variant: "destructive" });
    },
  });

  const deleteCollegeMutation = useMutation({
    mutationFn: (id: string) => apiRequest(`/api/colleges/${id}`, "DELETE"),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/colleges"] });
      toast({ title: "Success", description: "College deleted successfully" });
    },
    onError: () => {
      toast({ title: "Error", description: "Failed to delete college", variant: "destructive" });
    },
  });

  const createFacultyMutation = useMutation({
    mutationFn: (data: InsertFaculty) => apiRequest("/api/faculties", "POST", data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/faculties"] });
      toast({ title: "Success", description: "Faculty created successfully" });
    },
    onError: () => {
      toast({ title: "Error", description: "Failed to create faculty", variant: "destructive" });
    },
  });

  const updateFacultyMutation = useMutation({
    mutationFn: ({ id, data }: { id: string; data: InsertFaculty }) =>
      apiRequest(`/api/faculties/${id}`, "PATCH", data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/faculties"] });
      toast({ title: "Success", description: "Faculty updated successfully" });
    },
    onError: () => {
      toast({ title: "Error", description: "Failed to update faculty", variant: "destructive" });
    },
  });

  const deleteFacultyMutation = useMutation({
    mutationFn: (id: string) => apiRequest(`/api/faculties/${id}`, "DELETE"),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/faculties"] });
      toast({ title: "Success", description: "Faculty deleted successfully" });
    },
    onError: () => {
      toast({ title: "Error", description: "Failed to delete faculty", variant: "destructive" });
    },
  });

  const handleCollegeSubmit = (data: InsertCollege) => {
    if (selectedCollege) {
      updateCollegeMutation.mutate({ id: selectedCollege.id, data });
    } else {
      createCollegeMutation.mutate(data);
    }
  };

  const handleFacultySubmit = (data: InsertFaculty) => {
    if (selectedFaculty) {
      updateFacultyMutation.mutate({ id: selectedFaculty.id, data });
    } else {
      createFacultyMutation.mutate(data);
    }
  };

  const confirmDelete = () => {
    if (deleteTarget) {
      if (deleteTarget.type === "college") {
        deleteCollegeMutation.mutate(deleteTarget.id);
      } else {
        deleteFacultyMutation.mutate(deleteTarget.id);
      }
      setDeleteTarget(undefined);
    }
  };

  const collegesWithFaculties = colleges.map((college) => {
    const collegeFaculties = faculties.filter((f) => f.collegeId === college.id);
    return {
      id: college.id,
      name: college.name,
      faculties: collegeFaculties.map((faculty) => {
        const facultyYears = years.filter((y) => y.facultyId === faculty.id);
        return {
          id: faculty.id,
          name: faculty.name,
          years: facultyYears.map((year) => {
            const studentCount = students.filter((s) => s.yearId === year.id).length;
            return {
              id: year.id,
              name: year.name,
              studentCount,
            };
          }),
        };
      }),
    };
  });

  const stats = faculties.flatMap((faculty) => {
    const facultyYears = years.filter((y) => y.facultyId === faculty.id);
    return facultyYears.map((year) => {
      const yearStudents = students.filter((s) => s.yearId === year.id);
      const male = yearStudents.filter((s) => s.gender === "Male").length;
      const female = yearStudents.filter((s) => s.gender === "Female").length;
      const repeated = yearStudents.filter((s) => s.incidentType === "Repeated").length;
      const dismissed = yearStudents.filter((s) => s.incidentType === "Dismissed").length;
      const medical = yearStudents.filter((s) => s.incidentType === "Medical Discharge").length;

      return {
        faculty: faculty.name,
        year: year.name,
        total: yearStudents.length,
        male,
        female,
        repeated,
        dismissed,
        medical,
      };
    });
  });

  return (
    <div className="space-y-8">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-semibold">Colleges & Faculties</h1>
          <p className="text-muted-foreground mt-2">
            Hierarchical view of academic structure
          </p>
        </div>
        <div className="flex gap-2">
          <Button
            variant="outline"
            onClick={() => {
              setSelectedFaculty(undefined);
              setFacultyDialogOpen(true);
            }}
            data-testid="button-add-faculty"
          >
            <Plus className="h-4 w-4 mr-2" />
            Add Faculty
          </Button>
          <Button
            onClick={() => {
              setSelectedCollege(undefined);
              setCollegeDialogOpen(true);
            }}
            data-testid="button-add-college"
          >
            <Plus className="h-4 w-4 mr-2" />
            Add College
          </Button>
        </div>
      </div>

      {collegesLoading ? (
        <div className="text-center py-8">Loading colleges...</div>
      ) : (
        <div className="grid gap-6 lg:grid-cols-2">
          <div className="space-y-4">
            <h2 className="text-xl font-semibold">College Structure</h2>
            {collegesWithFaculties.length === 0 ? (
              <div className="text-center py-8 text-muted-foreground">
                No colleges found. Add a college to get started.
              </div>
            ) : (
              <CollegeTree
                colleges={collegesWithFaculties}
                onSelectYear={(collegeId, facultyId, yearId) => {
                  console.log("Selected:", { collegeId, facultyId, yearId });
                }}
              />
            )}
          </div>

          <div className="space-y-4">
            <h2 className="text-xl font-semibold">Student Statistics</h2>
            {stats.length === 0 ? (
              <div className="text-center py-8 text-muted-foreground">
                No statistics available yet.
              </div>
            ) : (
              <StatisticsPanel stats={stats} />
            )}
          </div>
        </div>
      )}

      <CollegeDialog
        open={collegeDialogOpen}
        onOpenChange={(open) => {
          setCollegeDialogOpen(open);
          if (!open) setSelectedCollege(undefined);
        }}
        onSubmit={handleCollegeSubmit}
        college={selectedCollege}
      />

      <FacultyDialog
        open={facultyDialogOpen}
        onOpenChange={(open) => {
          setFacultyDialogOpen(open);
          if (!open) setSelectedFaculty(undefined);
        }}
        onSubmit={handleFacultySubmit}
        faculty={selectedFaculty}
        colleges={colleges}
      />

      <DeleteAlertDialog
        open={deleteDialogOpen}
        onOpenChange={setDeleteDialogOpen}
        onConfirm={confirmDelete}
        title={`Delete ${deleteTarget?.type === "college" ? "College" : "Faculty"}`}
        description={`Are you sure you want to delete this ${deleteTarget?.type}? This action cannot be undone and will remove all associated data.`}
      />
    </div>
  );
}
