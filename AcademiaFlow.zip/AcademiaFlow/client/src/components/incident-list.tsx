import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { AlertTriangle, Calendar } from "lucide-react";

interface Incident {
  id: string;
  studentName: string;
  type: string;
  description?: string;
  date: string;
  faculty: string;
  year: string;
}

interface IncidentListProps {
  incidents: Incident[];
}

export function IncidentList({ incidents }: IncidentListProps) {
  const getIncidentBadgeVariant = (type: string) => {
    switch (type.toLowerCase()) {
      case "repeated":
        return "default";
      case "dismissed":
        return "destructive";
      case "medical discharge":
        return "secondary";
      default:
        return "outline";
    }
  };

  return (
    <div className="space-y-3">
      {incidents.length === 0 ? (
        <Card className="p-8 text-center">
          <p className="text-muted-foreground">No incidents recorded</p>
        </Card>
      ) : (
        incidents.map((incident) => (
          <Card
            key={incident.id}
            className="p-4 hover-elevate cursor-pointer"
            onClick={() => console.log('Incident clicked:', incident.id)}
            data-testid={`card-incident-${incident.id}`}
          >
            <div className="flex items-start gap-4">
              <div className="rounded-lg bg-destructive/10 p-2">
                <AlertTriangle className="h-4 w-4 text-destructive" />
              </div>
              <div className="flex-1 space-y-2">
                <div className="flex items-start justify-between gap-2 flex-wrap">
                  <div>
                    <h4 className="font-semibold">{incident.studentName}</h4>
                    <p className="text-sm text-muted-foreground">
                      {incident.faculty} - {incident.year}
                    </p>
                  </div>
                  <Badge variant={getIncidentBadgeVariant(incident.type)}>
                    {incident.type}
                  </Badge>
                </div>
                {incident.description && (
                  <p className="text-sm text-muted-foreground">{incident.description}</p>
                )}
                <div className="flex items-center gap-2 text-xs text-muted-foreground">
                  <Calendar className="h-3 w-3" />
                  {incident.date}
                </div>
              </div>
            </div>
          </Card>
        ))
      )}
    </div>
  );
}
