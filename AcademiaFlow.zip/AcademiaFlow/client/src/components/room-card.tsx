import { Card } from "@/components/ui/card";
import { DoorOpen } from "lucide-react";
import { Badge } from "@/components/ui/badge";

interface RoomCardProps {
  roomName: string;
  blockName: string;
  assignedTo?: {
    faculty: string;
    year: string;
  };
  onClick?: () => void;
}

export function RoomCard({ roomName, blockName, assignedTo, onClick }: RoomCardProps) {
  return (
    <Card
      className={`p-6 ${onClick ? 'cursor-pointer hover-elevate' : ''}`}
      onClick={() => {
        onClick?.();
        console.log('Room clicked:', roomName);
      }}
      data-testid={`card-room-${roomName.toLowerCase().replace(/\s+/g, '-')}`}
    >
      <div className="flex items-start gap-4">
        <div className="rounded-lg bg-primary/10 p-3">
          <DoorOpen className="h-5 w-5 text-primary" />
        </div>
        <div className="flex-1 space-y-2">
          <div className="flex items-center justify-between gap-2">
            <h3 className="font-semibold">{roomName}</h3>
            <Badge variant="outline" className="text-xs">
              {blockName}
            </Badge>
          </div>
          {assignedTo ? (
            <p className="text-sm text-muted-foreground">
              {assignedTo.faculty} - {assignedTo.year}
            </p>
          ) : (
            <p className="text-sm text-muted-foreground">Unassigned</p>
          )}
        </div>
      </div>
    </Card>
  );
}
