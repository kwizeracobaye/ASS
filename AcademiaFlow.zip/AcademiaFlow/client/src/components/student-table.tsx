import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Pencil, Trash2 } from "lucide-react";

interface Student {
  id: string;
  name: string;
  gender: string;
  faculty: string;
  year: string;
  incidentType?: string;
}

interface StudentTableProps {
  students: Student[];
  onEdit?: (student: Student) => void;
  onDelete?: (studentId: string) => void;
}

export function StudentTable({ students, onEdit, onDelete }: StudentTableProps) {
  const getIncidentBadgeVariant = (type?: string) => {
    if (!type) return undefined;
    switch (type.toLowerCase()) {
      case "repeated":
        return "default";
      case "dismissed":
        return "destructive";
      case "medical discharge":
        return "secondary";
      default:
        return "outline";
    }
  };

  return (
    <div className="rounded-md border">
      <Table>
        <TableHeader>
          <TableRow>
            <TableHead>Name</TableHead>
            <TableHead>Gender</TableHead>
            <TableHead>Faculty</TableHead>
            <TableHead>Year</TableHead>
            <TableHead>Incident</TableHead>
            <TableHead className="text-right">Actions</TableHead>
          </TableRow>
        </TableHeader>
        <TableBody>
          {students.length === 0 ? (
            <TableRow>
              <TableCell colSpan={6} className="text-center text-muted-foreground">
                No students found
              </TableCell>
            </TableRow>
          ) : (
            students.map((student) => (
              <TableRow key={student.id} data-testid={`row-student-${student.id}`}>
                <TableCell className="font-medium">{student.name}</TableCell>
                <TableCell>{student.gender}</TableCell>
                <TableCell>{student.faculty}</TableCell>
                <TableCell>{student.year}</TableCell>
                <TableCell>
                  {student.incidentType ? (
                    <Badge variant={getIncidentBadgeVariant(student.incidentType)}>
                      {student.incidentType}
                    </Badge>
                  ) : (
                    <span className="text-muted-foreground text-sm">None</span>
                  )}
                </TableCell>
                <TableCell className="text-right">
                  <div className="flex justify-end gap-2">
                    <Button
                      variant="ghost"
                      size="icon"
                      onClick={() => {
                        onEdit?.(student);
                        console.log('Edit student:', student.name);
                      }}
                      data-testid={`button-edit-${student.id}`}
                    >
                      <Pencil className="h-4 w-4" />
                    </Button>
                    <Button
                      variant="ghost"
                      size="icon"
                      onClick={() => {
                        onDelete?.(student.id);
                        console.log('Delete student:', student.name);
                      }}
                      data-testid={`button-delete-${student.id}`}
                    >
                      <Trash2 className="h-4 w-4" />
                    </Button>
                  </div>
                </TableCell>
              </TableRow>
            ))
          )}
        </TableBody>
      </Table>
    </div>
  );
}
