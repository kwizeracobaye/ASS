import { useState } from "react";
import { ChevronRight, ChevronDown, Building2, BookOpen, Calendar } from "lucide-react";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";

interface Year {
  id: string;
  name: string;
  studentCount: number;
}

interface Faculty {
  id: string;
  name: string;
  years: Year[];
}

interface College {
  id: string;
  name: string;
  faculties: Faculty[];
}

interface CollegeTreeProps {
  colleges: College[];
  onSelectYear?: (collegeId: string, facultyId: string, yearId: string) => void;
}

export function CollegeTree({ colleges, onSelectYear }: CollegeTreeProps) {
  const [expandedColleges, setExpandedColleges] = useState<Set<string>>(new Set());
  const [expandedFaculties, setExpandedFaculties] = useState<Set<string>>(new Set());

  const toggleCollege = (collegeId: string) => {
    const newExpanded = new Set(expandedColleges);
    if (newExpanded.has(collegeId)) {
      newExpanded.delete(collegeId);
    } else {
      newExpanded.add(collegeId);
    }
    setExpandedColleges(newExpanded);
  };

  const toggleFaculty = (facultyId: string) => {
    const newExpanded = new Set(expandedFaculties);
    if (newExpanded.has(facultyId)) {
      newExpanded.delete(facultyId);
    } else {
      newExpanded.add(facultyId);
    }
    setExpandedFaculties(newExpanded);
  };

  return (
    <div className="space-y-2">
      {colleges.map((college) => (
        <Card key={college.id} className="p-4" data-testid={`card-college-${college.id}`}>
          <div className="space-y-2">
            <Button
              variant="ghost"
              className="w-full justify-start gap-2 font-medium hover-elevate"
              onClick={() => toggleCollege(college.id)}
              data-testid={`button-toggle-college-${college.id}`}
            >
              {expandedColleges.has(college.id) ? (
                <ChevronDown className="h-4 w-4" />
              ) : (
                <ChevronRight className="h-4 w-4" />
              )}
              <Building2 className="h-4 w-4" />
              <span className="flex-1 text-left">{college.name}</span>
            </Button>

            {expandedColleges.has(college.id) && (
              <div className="ml-6 space-y-2 border-l-2 border-border pl-4">
                {college.faculties.map((faculty) => (
                  <div key={faculty.id}>
                    <Button
                      variant="ghost"
                      className="w-full justify-start gap-2 hover-elevate"
                      onClick={() => toggleFaculty(faculty.id)}
                      data-testid={`button-toggle-faculty-${faculty.id}`}
                    >
                      {expandedFaculties.has(faculty.id) ? (
                        <ChevronDown className="h-4 w-4" />
                      ) : (
                        <ChevronRight className="h-4 w-4" />
                      )}
                      <BookOpen className="h-4 w-4" />
                      <span className="flex-1 text-left">{faculty.name}</span>
                    </Button>

                    {expandedFaculties.has(faculty.id) && (
                      <div className="ml-6 space-y-1 border-l-2 border-border pl-4">
                        {faculty.years.map((year) => (
                          <Button
                            key={year.id}
                            variant="ghost"
                            className="w-full justify-start gap-2 text-sm hover-elevate"
                            onClick={() => {
                              onSelectYear?.(college.id, faculty.id, year.id);
                              console.log('Selected year:', year.name);
                            }}
                            data-testid={`button-year-${year.id}`}
                          >
                            <Calendar className="h-3 w-3" />
                            <span className="flex-1 text-left">{year.name}</span>
                            <Badge variant="secondary" className="text-xs">
                              {year.studentCount}
                            </Badge>
                          </Button>
                        ))}
                      </div>
                    )}
                  </div>
                ))}
              </div>
            )}
          </div>
        </Card>
      ))}
    </div>
  );
}
