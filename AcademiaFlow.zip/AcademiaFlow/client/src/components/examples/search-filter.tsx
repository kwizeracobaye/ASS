import { useState } from "react";
import { SearchFilter } from "../search-filter";

export default function SearchFilterExample() {
  const [search, setSearch] = useState("");
  const [faculty, setFaculty] = useState("all");
  const [year, setYear] = useState("all");

  return (
    <SearchFilter
      searchValue={search}
      onSearchChange={setSearch}
      filters={[
        {
          label: "Faculty",
          value: faculty,
          options: [
            { value: "all", label: "All Faculties" },
            { value: "math", label: "Mathematics" },
            { value: "physics", label: "Physics" },
          ],
          onChange: setFaculty,
        },
        {
          label: "Year",
          value: year,
          options: [
            { value: "all", label: "All Years" },
            { value: "1", label: "Year 1" },
            { value: "2", label: "Year 2" },
            { value: "3", label: "Year 3" },
          ],
          onChange: setYear,
        },
      ]}
      onClearFilters={() => {
        setSearch("");
        setFaculty("all");
        setYear("all");
      }}
    />
  );
}
