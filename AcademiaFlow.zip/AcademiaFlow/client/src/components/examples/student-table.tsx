import { StudentTable } from "../student-table";

export default function StudentTableExample() {
  const students = [
    {
      id: "1",
      name: "John Smith",
      gender: "Male",
      faculty: "Mathematics",
      year: "Year 1",
      incidentType: undefined,
    },
    {
      id: "2",
      name: "Sarah Johnson",
      gender: "Female",
      faculty: "Physics",
      year: "Year 2",
      incidentType: "Repeated",
    },
    {
      id: "3",
      name: "Michael Brown",
      gender: "Male",
      faculty: "Literature",
      year: "Year 3",
      incidentType: "Medical Discharge",
    },
  ];

  return <StudentTable students={students} />;
}
