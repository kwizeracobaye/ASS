import { StatisticsPanel } from "../statistics-panel";

export default function StatisticsPanelExample() {
  const stats = [
    {
      faculty: "Mathematics",
      year: "Year 1",
      total: 45,
      male: 28,
      female: 17,
      repeated: 2,
      dismissed: 0,
      medical: 1,
    },
    {
      faculty: "Mathematics",
      year: "Year 2",
      total: 38,
      male: 22,
      female: 16,
      repeated: 1,
      dismissed: 1,
      medical: 0,
    },
    {
      faculty: "Physics",
      year: "Year 1",
      total: 32,
      male: 20,
      female: 12,
      repeated: 0,
      dismissed: 0,
      medical: 0,
    },
  ];

  return <StatisticsPanel stats={stats} college="College of Science and Technology" />;
}
