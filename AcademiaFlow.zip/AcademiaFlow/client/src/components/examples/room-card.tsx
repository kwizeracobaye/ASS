import { RoomCard } from "../room-card";

export default function RoomCardExample() {
  return (
    <div className="space-y-4">
      <RoomCard
        roomName="Room 101"
        blockName="Academic Block"
        assignedTo={{ faculty: "Mathematics", year: "Year 2" }}
      />
      <RoomCard
        roomName="Room 205"
        blockName="Engineering Block"
      />
    </div>
  );
}
