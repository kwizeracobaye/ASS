import { StatCard } from "../stat-card";
import { GraduationCap } from "lucide-react";

export default function StatCardExample() {
  return (
    <StatCard
      title="Total Students"
      value="1,234"
      subtitle="567 Male, 667 Female"
      icon={GraduationCap}
      onClick={() => console.log('Stat card clicked')}
    />
  );
}
