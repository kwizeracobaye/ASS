import { CollegeTree } from "../college-tree";

export default function CollegeTreeExample() {
  const colleges = [
    {
      id: "1",
      name: "College of Science and Technology",
      faculties: [
        {
          id: "1-1",
          name: "Faculty of Mathematics",
          years: [
            { id: "1-1-1", name: "Year 1", studentCount: 45 },
            { id: "1-1-2", name: "Year 2", studentCount: 38 },
            { id: "1-1-3", name: "Year 3", studentCount: 42 },
          ],
        },
        {
          id: "1-2",
          name: "Faculty of Physics",
          years: [
            { id: "1-2-1", name: "Year 1", studentCount: 32 },
            { id: "1-2-2", name: "Year 2", studentCount: 29 },
          ],
        },
      ],
    },
    {
      id: "2",
      name: "College of Arts and Humanities",
      faculties: [
        {
          id: "2-1",
          name: "Faculty of Literature",
          years: [
            { id: "2-1-1", name: "Year 1", studentCount: 56 },
            { id: "2-1-2", name: "Year 2", studentCount: 48 },
          ],
        },
      ],
    },
  ];

  return <CollegeTree colleges={colleges} />;
}
