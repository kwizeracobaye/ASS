import { IncidentList } from "../incident-list";

export default function IncidentListExample() {
  const incidents = [
    {
      id: "1",
      studentName: "Sarah Johnson",
      type: "Repeated",
      description: "Repeated Year 2 due to academic performance",
      date: "2024-09-15",
      faculty: "Physics",
      year: "Year 2",
    },
    {
      id: "2",
      studentName: "Michael Brown",
      type: "Medical Discharge",
      description: "Medical leave approved for semester",
      date: "2024-10-01",
      faculty: "Literature",
      year: "Year 3",
    },
    {
      id: "3",
      studentName: "Emma Davis",
      type: "Dismissed",
      description: "Academic dismissal after probation period",
      date: "2024-08-20",
      faculty: "Mathematics",
      year: "Year 1",
    },
  ];

  return <IncidentList incidents={incidents} />;
}
