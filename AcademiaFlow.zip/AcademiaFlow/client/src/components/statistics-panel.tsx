import { Card } from "@/components/ui/card";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";

interface FacultyStats {
  faculty: string;
  year: string;
  total: number;
  male: number;
  female: number;
  repeated: number;
  dismissed: number;
  medical: number;
}

interface StatisticsPanelProps {
  stats: FacultyStats[];
  college?: string;
}

export function StatisticsPanel({ stats, college }: StatisticsPanelProps) {
  return (
    <Card className="p-6">
      <div className="space-y-4">
        {college && (
          <div className="flex items-center justify-between">
            <h3 className="text-xl font-semibold">{college}</h3>
            <Badge variant="outline">
              {stats.reduce((sum, s) => sum + s.total, 0)} Total Students
            </Badge>
          </div>
        )}
        <div className="rounded-md border">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Faculty</TableHead>
                <TableHead>Year</TableHead>
                <TableHead className="text-right">Total</TableHead>
                <TableHead className="text-right">Male</TableHead>
                <TableHead className="text-right">Female</TableHead>
                <TableHead className="text-right">Repeated</TableHead>
                <TableHead className="text-right">Dismissed</TableHead>
                <TableHead className="text-right">Medical</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {stats.map((stat, idx) => (
                <TableRow key={idx} data-testid={`row-stat-${idx}`}>
                  <TableCell className="font-medium">{stat.faculty}</TableCell>
                  <TableCell>{stat.year}</TableCell>
                  <TableCell className="text-right">{stat.total}</TableCell>
                  <TableCell className="text-right">{stat.male}</TableCell>
                  <TableCell className="text-right">{stat.female}</TableCell>
                  <TableCell className="text-right">
                    {stat.repeated > 0 ? (
                      <Badge variant="default" className="text-xs">
                        {stat.repeated}
                      </Badge>
                    ) : (
                      <span className="text-muted-foreground">0</span>
                    )}
                  </TableCell>
                  <TableCell className="text-right">
                    {stat.dismissed > 0 ? (
                      <Badge variant="destructive" className="text-xs">
                        {stat.dismissed}
                      </Badge>
                    ) : (
                      <span className="text-muted-foreground">0</span>
                    )}
                  </TableCell>
                  <TableCell className="text-right">
                    {stat.medical > 0 ? (
                      <Badge variant="secondary" className="text-xs">
                        {stat.medical}
                      </Badge>
                    ) : (
                      <span className="text-muted-foreground">0</span>
                    )}
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </div>
      </div>
    </Card>
  );
}
