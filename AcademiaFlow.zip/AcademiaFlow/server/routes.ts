import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import {
  insertCollegeSchema,
  insertFacultySchema,
  insertYearSchema,
  insertStudentSchema,
  insertBlockSchema,
  insertRoomSchema,
  insertIncidentSchema,
} from "@shared/schema";

export async function registerRoutes(app: Express): Promise<Server> {
  app.get("/api/colleges", async (_req, res) => {
    const colleges = await storage.getColleges();
    res.json(colleges);
  });

  app.get("/api/colleges/:id", async (req, res) => {
    const college = await storage.getCollege(req.params.id);
    if (!college) {
      return res.status(404).json({ error: "College not found" });
    }
    res.json(college);
  });

  app.post("/api/colleges", async (req, res) => {
    try {
      const data = insertCollegeSchema.parse(req.body);
      const college = await storage.createCollege(data);
      res.status(201).json(college);
    } catch (error) {
      res.status(400).json({ error: "Invalid data" });
    }
  });

  app.patch("/api/colleges/:id", async (req, res) => {
    try {
      const data = insertCollegeSchema.parse(req.body);
      const college = await storage.updateCollege(req.params.id, data);
      if (!college) {
        return res.status(404).json({ error: "College not found" });
      }
      res.json(college);
    } catch (error) {
      res.status(400).json({ error: "Invalid data" });
    }
  });

  app.delete("/api/colleges/:id", async (req, res) => {
    const success = await storage.deleteCollege(req.params.id);
    if (!success) {
      return res.status(404).json({ error: "College not found" });
    }
    res.status(204).send();
  });

  app.get("/api/faculties", async (_req, res) => {
    const faculties = await storage.getFaculties();
    res.json(faculties);
  });

  app.get("/api/faculties/:id", async (req, res) => {
    const faculty = await storage.getFaculty(req.params.id);
    if (!faculty) {
      return res.status(404).json({ error: "Faculty not found" });
    }
    res.json(faculty);
  });

  app.post("/api/faculties", async (req, res) => {
    try {
      const data = insertFacultySchema.parse(req.body);
      const faculty = await storage.createFaculty(data);
      res.status(201).json(faculty);
    } catch (error) {
      res.status(400).json({ error: "Invalid data" });
    }
  });

  app.patch("/api/faculties/:id", async (req, res) => {
    try {
      const data = insertFacultySchema.parse(req.body);
      const faculty = await storage.updateFaculty(req.params.id, data);
      if (!faculty) {
        return res.status(404).json({ error: "Faculty not found" });
      }
      res.json(faculty);
    } catch (error) {
      res.status(400).json({ error: "Invalid data" });
    }
  });

  app.delete("/api/faculties/:id", async (req, res) => {
    const success = await storage.deleteFaculty(req.params.id);
    if (!success) {
      return res.status(404).json({ error: "Faculty not found" });
    }
    res.status(204).send();
  });

  app.get("/api/years", async (_req, res) => {
    const years = await storage.getYears();
    res.json(years);
  });

  app.get("/api/years/:id", async (req, res) => {
    const year = await storage.getYear(req.params.id);
    if (!year) {
      return res.status(404).json({ error: "Year not found" });
    }
    res.json(year);
  });

  app.post("/api/years", async (req, res) => {
    try {
      const data = insertYearSchema.parse(req.body);
      const year = await storage.createYear(data);
      res.status(201).json(year);
    } catch (error) {
      res.status(400).json({ error: "Invalid data" });
    }
  });

  app.patch("/api/years/:id", async (req, res) => {
    try {
      const data = insertYearSchema.parse(req.body);
      const year = await storage.updateYear(req.params.id, data);
      if (!year) {
        return res.status(404).json({ error: "Year not found" });
      }
      res.json(year);
    } catch (error) {
      res.status(400).json({ error: "Invalid data" });
    }
  });

  app.delete("/api/years/:id", async (req, res) => {
    const success = await storage.deleteYear(req.params.id);
    if (!success) {
      return res.status(404).json({ error: "Year not found" });
    }
    res.status(204).send();
  });

  app.get("/api/students", async (_req, res) => {
    const students = await storage.getStudents();
    res.json(students);
  });

  app.get("/api/students/:id", async (req, res) => {
    const student = await storage.getStudent(req.params.id);
    if (!student) {
      return res.status(404).json({ error: "Student not found" });
    }
    res.json(student);
  });

  app.post("/api/students", async (req, res) => {
    try {
      const data = insertStudentSchema.parse(req.body);
      const student = await storage.createStudent(data);
      res.status(201).json(student);
    } catch (error) {
      res.status(400).json({ error: "Invalid data" });
    }
  });

  app.patch("/api/students/:id", async (req, res) => {
    try {
      const data = insertStudentSchema.parse(req.body);
      const student = await storage.updateStudent(req.params.id, data);
      if (!student) {
        return res.status(404).json({ error: "Student not found" });
      }
      res.json(student);
    } catch (error) {
      res.status(400).json({ error: "Invalid data" });
    }
  });

  app.delete("/api/students/:id", async (req, res) => {
    const success = await storage.deleteStudent(req.params.id);
    if (!success) {
      return res.status(404).json({ error: "Student not found" });
    }
    res.status(204).send();
  });

  app.get("/api/blocks", async (_req, res) => {
    const blocks = await storage.getBlocks();
    res.json(blocks);
  });

  app.get("/api/blocks/:id", async (req, res) => {
    const block = await storage.getBlock(req.params.id);
    if (!block) {
      return res.status(404).json({ error: "Block not found" });
    }
    res.json(block);
  });

  app.post("/api/blocks", async (req, res) => {
    try {
      const data = insertBlockSchema.parse(req.body);
      const block = await storage.createBlock(data);
      res.status(201).json(block);
    } catch (error) {
      res.status(400).json({ error: "Invalid data" });
    }
  });

  app.patch("/api/blocks/:id", async (req, res) => {
    try {
      const data = insertBlockSchema.parse(req.body);
      const block = await storage.updateBlock(req.params.id, data);
      if (!block) {
        return res.status(404).json({ error: "Block not found" });
      }
      res.json(block);
    } catch (error) {
      res.status(400).json({ error: "Invalid data" });
    }
  });

  app.delete("/api/blocks/:id", async (req, res) => {
    const success = await storage.deleteBlock(req.params.id);
    if (!success) {
      return res.status(404).json({ error: "Block not found" });
    }
    res.status(204).send();
  });

  app.get("/api/rooms", async (_req, res) => {
    const rooms = await storage.getRooms();
    res.json(rooms);
  });

  app.get("/api/rooms/:id", async (req, res) => {
    const room = await storage.getRoom(req.params.id);
    if (!room) {
      return res.status(404).json({ error: "Room not found" });
    }
    res.json(room);
  });

  app.post("/api/rooms", async (req, res) => {
    try {
      const data = insertRoomSchema.parse(req.body);
      const room = await storage.createRoom(data);
      res.status(201).json(room);
    } catch (error) {
      res.status(400).json({ error: "Invalid data" });
    }
  });

  app.patch("/api/rooms/:id", async (req, res) => {
    try {
      const data = insertRoomSchema.parse(req.body);
      const room = await storage.updateRoom(req.params.id, data);
      if (!room) {
        return res.status(404).json({ error: "Room not found" });
      }
      res.json(room);
    } catch (error) {
      res.status(400).json({ error: "Invalid data" });
    }
  });

  app.delete("/api/rooms/:id", async (req, res) => {
    const success = await storage.deleteRoom(req.params.id);
    if (!success) {
      return res.status(404).json({ error: "Room not found" });
    }
    res.status(204).send();
  });

  app.get("/api/incidents", async (_req, res) => {
    const incidents = await storage.getIncidents();
    res.json(incidents);
  });

  app.get("/api/incidents/:id", async (req, res) => {
    const incident = await storage.getIncident(req.params.id);
    if (!incident) {
      return res.status(404).json({ error: "Incident not found" });
    }
    res.json(incident);
  });

  app.post("/api/incidents", async (req, res) => {
    try {
      const data = insertIncidentSchema.parse(req.body);
      const incident = await storage.createIncident(data);
      res.status(201).json(incident);
    } catch (error) {
      res.status(400).json({ error: "Invalid data" });
    }
  });

  app.patch("/api/incidents/:id", async (req, res) => {
    try {
      const data = insertIncidentSchema.parse(req.body);
      const incident = await storage.updateIncident(req.params.id, data);
      if (!incident) {
        return res.status(404).json({ error: "Incident not found" });
      }
      res.json(incident);
    } catch (error) {
      res.status(400).json({ error: "Invalid data" });
    }
  });

  app.delete("/api/incidents/:id", async (req, res) => {
    const success = await storage.deleteIncident(req.params.id);
    if (!success) {
      return res.status(404).json({ error: "Incident not found" });
    }
    res.status(204).send();
  });

  const httpServer = createServer(app);

  return httpServer;
}
