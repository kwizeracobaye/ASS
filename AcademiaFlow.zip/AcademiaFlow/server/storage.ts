import {
  type College,
  type InsertCollege,
  type Faculty,
  type InsertFaculty,
  type Year,
  type InsertYear,
  type Student,
  type InsertStudent,
  type Block,
  type InsertBlock,
  type Room,
  type InsertRoom,
  type Incident,
  type InsertIncident,
} from "@shared/schema";
import { randomUUID } from "crypto";

export interface IStorage {
  getColleges(): Promise<College[]>;
  getCollege(id: string): Promise<College | undefined>;
  createCollege(college: InsertCollege): Promise<College>;
  updateCollege(id: string, college: InsertCollege): Promise<College | undefined>;
  deleteCollege(id: string): Promise<boolean>;

  getFaculties(): Promise<Faculty[]>;
  getFacultiesByCollege(collegeId: string): Promise<Faculty[]>;
  getFaculty(id: string): Promise<Faculty | undefined>;
  createFaculty(faculty: InsertFaculty): Promise<Faculty>;
  updateFaculty(id: string, faculty: InsertFaculty): Promise<Faculty | undefined>;
  deleteFaculty(id: string): Promise<boolean>;

  getYears(): Promise<Year[]>;
  getYearsByFaculty(facultyId: string): Promise<Year[]>;
  getYear(id: string): Promise<Year | undefined>;
  createYear(year: InsertYear): Promise<Year>;
  updateYear(id: string, year: InsertYear): Promise<Year | undefined>;
  deleteYear(id: string): Promise<boolean>;

  getStudents(): Promise<Student[]>;
  getStudent(id: string): Promise<Student | undefined>;
  createStudent(student: InsertStudent): Promise<Student>;
  updateStudent(id: string, student: InsertStudent): Promise<Student | undefined>;
  deleteStudent(id: string): Promise<boolean>;

  getBlocks(): Promise<Block[]>;
  getBlock(id: string): Promise<Block | undefined>;
  createBlock(block: InsertBlock): Promise<Block>;
  updateBlock(id: string, block: InsertBlock): Promise<Block | undefined>;
  deleteBlock(id: string): Promise<boolean>;

  getRooms(): Promise<Room[]>;
  getRoom(id: string): Promise<Room | undefined>;
  createRoom(room: InsertRoom): Promise<Room>;
  updateRoom(id: string, room: InsertRoom): Promise<Room | undefined>;
  deleteRoom(id: string): Promise<boolean>;

  getIncidents(): Promise<Incident[]>;
  getIncident(id: string): Promise<Incident | undefined>;
  createIncident(incident: InsertIncident): Promise<Incident>;
  updateIncident(id: string, incident: InsertIncident): Promise<Incident | undefined>;
  deleteIncident(id: string): Promise<boolean>;
}

export class MemStorage implements IStorage {
  private colleges: Map<string, College>;
  private faculties: Map<string, Faculty>;
  private years: Map<string, Year>;
  private students: Map<string, Student>;
  private blocks: Map<string, Block>;
  private rooms: Map<string, Room>;
  private incidents: Map<string, Incident>;

  constructor() {
    this.colleges = new Map();
    this.faculties = new Map();
    this.years = new Map();
    this.students = new Map();
    this.blocks = new Map();
    this.rooms = new Map();
    this.incidents = new Map();
  }

  async getColleges(): Promise<College[]> {
    return Array.from(this.colleges.values());
  }

  async getCollege(id: string): Promise<College | undefined> {
    return this.colleges.get(id);
  }

  async createCollege(insertCollege: InsertCollege): Promise<College> {
    const id = randomUUID();
    const college: College = { ...insertCollege, id };
    this.colleges.set(id, college);
    return college;
  }

  async updateCollege(id: string, insertCollege: InsertCollege): Promise<College | undefined> {
    if (!this.colleges.has(id)) return undefined;
    const college: College = { ...insertCollege, id };
    this.colleges.set(id, college);
    return college;
  }

  async deleteCollege(id: string): Promise<boolean> {
    return this.colleges.delete(id);
  }

  async getFaculties(): Promise<Faculty[]> {
    return Array.from(this.faculties.values());
  }

  async getFacultiesByCollege(collegeId: string): Promise<Faculty[]> {
    return Array.from(this.faculties.values()).filter(
      (faculty) => faculty.collegeId === collegeId
    );
  }

  async getFaculty(id: string): Promise<Faculty | undefined> {
    return this.faculties.get(id);
  }

  async createFaculty(insertFaculty: InsertFaculty): Promise<Faculty> {
    const id = randomUUID();
    const faculty: Faculty = { ...insertFaculty, id };
    this.faculties.set(id, faculty);
    return faculty;
  }

  async updateFaculty(id: string, insertFaculty: InsertFaculty): Promise<Faculty | undefined> {
    if (!this.faculties.has(id)) return undefined;
    const faculty: Faculty = { ...insertFaculty, id };
    this.faculties.set(id, faculty);
    return faculty;
  }

  async deleteFaculty(id: string): Promise<boolean> {
    return this.faculties.delete(id);
  }

  async getYears(): Promise<Year[]> {
    return Array.from(this.years.values());
  }

  async getYearsByFaculty(facultyId: string): Promise<Year[]> {
    return Array.from(this.years.values()).filter(
      (year) => year.facultyId === facultyId
    );
  }

  async getYear(id: string): Promise<Year | undefined> {
    return this.years.get(id);
  }

  async createYear(insertYear: InsertYear): Promise<Year> {
    const id = randomUUID();
    const year: Year = { ...insertYear, id };
    this.years.set(id, year);
    return year;
  }

  async updateYear(id: string, insertYear: InsertYear): Promise<Year | undefined> {
    if (!this.years.has(id)) return undefined;
    const year: Year = { ...insertYear, id };
    this.years.set(id, year);
    return year;
  }

  async deleteYear(id: string): Promise<boolean> {
    return this.years.delete(id);
  }

  async getStudents(): Promise<Student[]> {
    return Array.from(this.students.values());
  }

  async getStudent(id: string): Promise<Student | undefined> {
    return this.students.get(id);
  }

  async createStudent(insertStudent: InsertStudent): Promise<Student> {
    const id = randomUUID();
    const student: Student = {
      ...insertStudent,
      id,
      incidentType: insertStudent.incidentType ?? null,
    };
    this.students.set(id, student);
    return student;
  }

  async updateStudent(id: string, insertStudent: InsertStudent): Promise<Student | undefined> {
    if (!this.students.has(id)) return undefined;
    const student: Student = {
      ...insertStudent,
      id,
      incidentType: insertStudent.incidentType ?? null,
    };
    this.students.set(id, student);
    return student;
  }

  async deleteStudent(id: string): Promise<boolean> {
    return this.students.delete(id);
  }

  async getBlocks(): Promise<Block[]> {
    return Array.from(this.blocks.values());
  }

  async getBlock(id: string): Promise<Block | undefined> {
    return this.blocks.get(id);
  }

  async createBlock(insertBlock: InsertBlock): Promise<Block> {
    const id = randomUUID();
    const block: Block = { ...insertBlock, id };
    this.blocks.set(id, block);
    return block;
  }

  async updateBlock(id: string, insertBlock: InsertBlock): Promise<Block | undefined> {
    if (!this.blocks.has(id)) return undefined;
    const block: Block = { ...insertBlock, id };
    this.blocks.set(id, block);
    return block;
  }

  async deleteBlock(id: string): Promise<boolean> {
    return this.blocks.delete(id);
  }

  async getRooms(): Promise<Room[]> {
    return Array.from(this.rooms.values());
  }

  async getRoom(id: string): Promise<Room | undefined> {
    return this.rooms.get(id);
  }

  async createRoom(insertRoom: InsertRoom): Promise<Room> {
    const id = randomUUID();
    const room: Room = {
      ...insertRoom,
      id,
      facultyId: insertRoom.facultyId ?? null,
      yearId: insertRoom.yearId ?? null,
    };
    this.rooms.set(id, room);
    return room;
  }

  async updateRoom(id: string, insertRoom: InsertRoom): Promise<Room | undefined> {
    if (!this.rooms.has(id)) return undefined;
    const room: Room = {
      ...insertRoom,
      id,
      facultyId: insertRoom.facultyId ?? null,
      yearId: insertRoom.yearId ?? null,
    };
    this.rooms.set(id, room);
    return room;
  }

  async deleteRoom(id: string): Promise<boolean> {
    return this.rooms.delete(id);
  }

  async getIncidents(): Promise<Incident[]> {
    return Array.from(this.incidents.values());
  }

  async getIncident(id: string): Promise<Incident | undefined> {
    return this.incidents.get(id);
  }

  async createIncident(insertIncident: InsertIncident): Promise<Incident> {
    const id = randomUUID();
    const incident: Incident = {
      ...insertIncident,
      id,
      description: insertIncident.description ?? null,
    };
    this.incidents.set(id, incident);
    return incident;
  }

  async updateIncident(id: string, insertIncident: InsertIncident): Promise<Incident | undefined> {
    if (!this.incidents.has(id)) return undefined;
    const incident: Incident = {
      ...insertIncident,
      id,
      description: insertIncident.description ?? null,
    };
    this.incidents.set(id, incident);
    return incident;
  }

  async deleteIncident(id: string): Promise<boolean> {
    return this.incidents.delete(id);
  }
}

export const storage = new MemStorage();
