# Academic Management Dashboard - Design Guidelines

## Design Approach
**Selected System:** Material Design with data-focused optimizations
**Justification:** This is a utility-focused, information-dense administrative application requiring clarity, efficiency, and standard UI patterns. Material Design provides excellent components for tables, hierarchical navigation, and data visualization while maintaining professional aesthetics suitable for academic institutions.

**Key Design Principles:**
- Clarity over decoration - every element serves a functional purpose
- Consistent visual hierarchy for rapid information scanning
- Professional, trustworthy aesthetic appropriate for educational institutions
- Efficient navigation with minimal clicks to reach data

## Core Design Elements

### A. Color Palette

**Light Mode:**
- Primary: 210 100% 45% (Deep blue - academic, professional)
- Primary Variant: 210 95% 35% (Darker blue for hover states)
- Background: 0 0% 98% (Near-white for reduced eye strain)
- Surface: 0 0% 100% (Pure white for cards and panels)
- Text Primary: 220 15% 15% (Near-black for optimal readability)
- Text Secondary: 220 10% 45% (Medium gray for labels)
- Border: 220 15% 90% (Light gray for subtle divisions)
- Success: 140 60% 45% (For positive indicators)
- Warning: 35 90% 55% (For incidents/alerts)
- Error: 5 75% 50% (For dismissals/critical data)

**Dark Mode:**
- Primary: 210 100% 60% (Brighter blue for dark backgrounds)
- Primary Variant: 210 95% 50%
- Background: 220 20% 12% (Deep blue-gray)
- Surface: 220 18% 16% (Slightly lighter for cards)
- Text Primary: 0 0% 95% (Near-white)
- Text Secondary: 0 0% 65%
- Border: 220 15% 25%

### B. Typography

**Font Families:**
- Primary: 'Inter' (Google Fonts) - Excellent readability for data-dense interfaces
- Monospace: 'JetBrains Mono' - For student IDs, room numbers

**Scale:**
- Headings: text-3xl (Dashboard title), text-2xl (Section headers), text-xl (Card titles)
- Body: text-base (Standard content, table data)
- Small: text-sm (Labels, metadata)
- Micro: text-xs (Table headers, badges)

**Weights:**
- font-semibold for headings and important data points
- font-medium for section labels and navigation
- font-normal for body text and table content

### C. Layout System

**Spacing Primitives:** Tailwind units of 2, 4, 6, 8, and 12
- Component padding: p-6 (cards, panels)
- Section spacing: space-y-8 (between major sections)
- Element gaps: gap-4 (grid items, button groups)
- Table cells: p-4 (data table cells)
- Tight groupings: space-y-2 (form labels and inputs)

**Grid System:**
- Dashboard cards: grid-cols-1 md:grid-cols-2 lg:grid-cols-4
- Statistics tables: Full-width responsive tables with horizontal scroll on mobile
- Navigation sidebar: 280px fixed width on desktop, collapsible drawer on mobile

### D. Component Library

**Navigation:**
- Top bar: Full-width header with app title, user menu, and quick actions
- Sidebar: Vertical navigation with expandable/collapsible sections for College → Faculty → Year hierarchy
- Breadcrumbs: Show current location in hierarchy (e.g., CST > Mathematics > Year 1)

**Dashboard Cards:**
- Elevated cards (shadow-md) with rounded-lg corners
- Header with icon, title, and primary metric (large text-4xl number)
- Subtext showing breakdown (e.g., "15 Male, 8 Female")
- Subtle border-l-4 accent in primary color

**Data Tables:**
- Striped rows (alternate background colors) for improved scanning
- Sticky headers for long tables
- Sortable columns with clear indicators
- Row hover states with subtle background change
- Action buttons (edit, delete) appear on row hover
- Compact mode toggle for dense data views

**Forms:**
- Grouped fieldsets with clear labels above inputs
- Full-width inputs with subtle borders
- Dropdowns for College/Faculty/Year selection
- Radio buttons for gender selection
- Text areas for incident descriptions
- Clear validation states (success/error borders and messages)

**Hierarchical Tree View:**
- Indented structure with connecting lines
- Expand/collapse icons (chevron-right/down)
- Hover states on clickable items
- Badge counts showing student numbers next to each node

**Statistics Panels:**
- Horizontal stat bars for gender distribution
- Badge components for incident counts (color-coded: yellow for repeats, red for dismissals, blue for medical)
- Compact metric displays (icon + number + label)

**Filters & Search:**
- Search bar with magnifying glass icon
- Multi-select dropdowns for College/Faculty/Year filtering
- Clear filter button
- Active filter tags displayed above results

### E. Responsive Behavior

**Desktop (lg and above):**
- Persistent sidebar navigation
- Multi-column dashboard (4 cards across)
- Full-width data tables with all columns visible

**Tablet (md):**
- Collapsible sidebar (hamburger menu)
- 2-column dashboard cards
- Tables begin to stack certain columns

**Mobile (base):**
- Hidden sidebar (drawer overlay when opened)
- Single-column card layout
- Card-based table presentation (each row becomes a card)
- Sticky action buttons at bottom

### F. Interactive States

**Buttons:**
- Primary: Filled with primary color, white text
- Secondary: Outline style with primary color border
- Ghost: Text-only for tertiary actions
- States: Subtle transform on hover, active state with slight scale

**Links:**
- Underline on hover
- Primary color text
- Visited state slightly muted

**Cards:**
- Subtle shadow elevation on hover
- Smooth transition (150ms)
- Cursor pointer on clickable cards

## Special Considerations

**Data Visualization:**
- Use simple bar charts for gender distribution
- Pie charts for incident type breakdown
- Trend lines if historical data exists
- Keep charts minimal and functional, not decorative

**Accessibility:**
- WCAG 2.1 AA compliant color contrast
- Keyboard navigation for all interactive elements
- Screen reader labels for icons and data points
- Focus indicators on all focusable elements

**Empty States:**
- Friendly illustrations or icons
- Clear instructions on how to add first entry
- "Add New" button prominently displayed

**Loading States:**
- Skeleton screens for tables while data loads
- Spinner for quick actions
- Progress bars for multi-step operations

This design creates a professional, efficient, and scalable academic management system that prioritizes data clarity and user productivity while maintaining institutional credibility.