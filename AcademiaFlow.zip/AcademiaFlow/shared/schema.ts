import { sql } from "drizzle-orm";
import { pgTable, text, varchar, integer } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const colleges = pgTable("colleges", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  name: text("name").notNull(),
});

export const faculties = pgTable("faculties", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  name: text("name").notNull(),
  collegeId: varchar("college_id").notNull().references(() => colleges.id, { onDelete: "cascade" }),
});

export const years = pgTable("years", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  name: text("name").notNull(),
  facultyId: varchar("faculty_id").notNull().references(() => faculties.id, { onDelete: "cascade" }),
});

export const students = pgTable("students", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  name: text("name").notNull(),
  gender: text("gender").notNull(),
  facultyId: varchar("faculty_id").notNull().references(() => faculties.id, { onDelete: "cascade" }),
  yearId: varchar("year_id").notNull().references(() => years.id, { onDelete: "cascade" }),
  incidentType: text("incident_type").default(sql`NULL`),
});

export const blocks = pgTable("blocks", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  name: text("name").notNull(),
});

export const rooms = pgTable("rooms", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  name: text("name").notNull(),
  blockId: varchar("block_id").notNull().references(() => blocks.id, { onDelete: "cascade" }),
  facultyId: varchar("faculty_id").references(() => faculties.id, { onDelete: "set null" }).default(sql`NULL`),
  yearId: varchar("year_id").references(() => years.id, { onDelete: "set null" }).default(sql`NULL`),
});

export const incidents = pgTable("incidents", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  studentId: varchar("student_id").notNull().references(() => students.id, { onDelete: "cascade" }),
  type: text("type").notNull(),
  description: text("description").default(sql`NULL`),
  date: text("date").notNull(),
});

export const insertCollegeSchema = createInsertSchema(colleges).omit({ id: true });
export const insertFacultySchema = createInsertSchema(faculties).omit({ id: true });
export const insertYearSchema = createInsertSchema(years).omit({ id: true });
export const insertStudentSchema = createInsertSchema(students).omit({ id: true });
export const insertBlockSchema = createInsertSchema(blocks).omit({ id: true });
export const insertRoomSchema = createInsertSchema(rooms).omit({ id: true });
export const insertIncidentSchema = createInsertSchema(incidents).omit({ id: true });

export type InsertCollege = z.infer<typeof insertCollegeSchema>;
export type College = typeof colleges.$inferSelect;

export type InsertFaculty = z.infer<typeof insertFacultySchema>;
export type Faculty = typeof faculties.$inferSelect;

export type InsertYear = z.infer<typeof insertYearSchema>;
export type Year = typeof years.$inferSelect;

export type InsertStudent = z.infer<typeof insertStudentSchema>;
export type Student = typeof students.$inferSelect;

export type InsertBlock = z.infer<typeof insertBlockSchema>;
export type Block = typeof blocks.$inferSelect;

export type InsertRoom = z.infer<typeof insertRoomSchema>;
export type Room = typeof rooms.$inferSelect;

export type InsertIncident = z.infer<typeof insertIncidentSchema>;
export type Incident = typeof incidents.$inferSelect;
